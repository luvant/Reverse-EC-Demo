CKEDITOR.plugins.setLang( 'html5audio', 'zh-cn', {
    button: '插入HTML5音频',
    title: 'HTML5 音频',
    infoLabel: '音频信息',
    urlMissing: '音频URL',
    audioProperties: '音频属性',
    upload: '上传',
    btnUpload: '上传到服务器',
    advanced: '高级',
    autoplay: '自动播放?',
    allowdownload: '允许下载?',
    yes: '是',
    no: '否'
} );
